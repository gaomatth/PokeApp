//
//  NavView.swift
//  PokeApp
//
//  Created by Nguyễn Đức Quang on 4/11/21.
//

import SwiftUI

struct NavView: View {
    var body: some View {
        
    }
}

struct NavView_Previews: PreviewProvider {
    static var previews: some View {
        NavView()
    }
}
